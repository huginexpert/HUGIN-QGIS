from .plugin import ProcessingScriptCollectionPlugin

def classFactory(iface):
    return ProcessingScriptCollectionPlugin()
